//
//  ViewController.swift
//  Right on target
//
//  Created by Артем Бажанов on 04.04.2022.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet var slider: UISlider!
    @IBOutlet var label: UILabel!
    
    //создаем ленивое свойство для хранения в памяти второй сцены после загрузки
    lazy var secondViewController: SecondViewController = getSecondViewController()
    //приватный метод, загружающий view controller
    private func getSecondViewController() -> SecondViewController {
        //загрузка сториборда
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        //загрузка viewcontroller и его сцены со сториборда
        let viewController = storyboard.instantiateViewController(withIdentifier: "SecondViewController")
        //возвращаем приведенный вью контролер к типу секонд вью контролер
        return viewController as! SecondViewController
    }
    
    
    //метод перехода с одного на экрана на другой через кнопку без сигвеев
    @IBAction func showNextScreen(){
 
        self.present(secondViewController, animated: true, completion: nil)
    }
 
   
    
    var number: Int = 0
    var round: Int = 1
    var points: Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("viewDidLoad")

            //генерируем случайное число
            self.number = Int.random(in: 1...50)
            //передаем значение числа в текст.метку
            self.label.text = String(self.number)
            //устанавливаем счетчик райндов на +1
            self.round += 1
        
    }
    
    @IBAction func checkNumber() {
            //получаем значение на слайдере
            let numSlider = Int(self.slider.value.rounded())
            //сравниваем значение с загаданным и считаем очки
            if numSlider > self.number {
                self.points += 50 - numSlider + self.number
            }
            if numSlider < self.number {
                self.points += 50 + numSlider - self.number
            }
            if numSlider == 50 {
                self.points += 50 * 2
            }
            if self.round == 5 {
                //выводим результат игры
                let alert = UIAlertController(title: "Игра окончена", message: "Вы заработали \(self.points) очков!", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Начать заново", style: .default, handler: nil))
                self.present(alert, animated: true, completion: nil)
                self.round = 1
                self.points = 0
            } else {
                self.round += 1
            }
            //генерируем новое число
            self.number = Int.random(in: 1...50)
            //передаем значение числа в label
            self.label.text = String(self.number)
        }
    
    override func loadView() {
        super.loadView()
        print("loadView")
        // создаем метку о выводе версии приложения
        let versionLabel = UILabel(frame: CGRect(x: 20, y: 10, width: 200, height: 20))
        //изменяем текст метки
        versionLabel.text = "Version 1.1"
        //добавляем метку в родительский view
        self.view.addSubview(versionLabel)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        print("viewWillAppear")
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        print("viewDidAppear")
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        print("viewWillDisappear")
    }
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        print("viewDidDisappear")
    }
    }


